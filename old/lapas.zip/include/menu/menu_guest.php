<li><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Laporan <span class="caret"></span></a>
    <ul class="dropdown-menu multi-level" role="menu" aria-labelledby="dropdownMenu">
        <li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=laporan_perencanaan" title="Laporan Tahap Kesiapan Pelaksanaan">Tahap Kesiapan Pelaksanaan</a></li>
        <li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=laporan_pelaksanaan" title="Laporan Tahap Pelaksanaan Konstruksi">Tahap Pelaksanaan Konstruksi</a></li>
        <li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=laporan_pascaKonstruksi" title="Laporan Tahap Pasca Konstruksi">Tahap Pasca Konstruksi</a></li>
    </ul>
</li>