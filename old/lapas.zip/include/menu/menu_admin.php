<li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=input_perencanaan" title="Input Data Tahap Kesiapan Pelaksanaan">Input Data</a></li>
<li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=output_perencanaan" title="Output Data">Output Data</a></li>
<li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=laporan_perencanaan" title="Laporan Tahap Kesiapan Pelaksanaan">Laporan</a></li>
<li><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Management Data <span class="caret"></span></a>
    <ul class="dropdown-menu multi-level" role="menu" aria-labelledby="dropdownMenu">
        <li class="dropdown-submenu"><a tabindex="0" data-toggle="dropdown" href="#">Elemen Assessment</a>
            <ul class="dropdown-menu">
                <li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=param_tahap_perencanaan" title="Instrument Deteksi Dini">Instrument Deteksi Dini</a></li>
            </ul>
        </li>
        <li role="separator" class="divider"></li>
        <li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=param_setting" title="Web Setting">Web Setting</a></li>
    </ul>
</li>