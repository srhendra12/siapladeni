<li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=input_perencanaan" title="Input Data Tahap Kesiapan Pelaksanaan">Input Data</a></li>
<li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=output_perencanaan" title="Output Data">Output Data</a></li>
<li><a tabindex="0" href="<?=BASE_URL_MENU?>?fl=laporan_perencanaan" title="Laporan Tahap Kesiapan Pelaksanaan">Laporan</a></li>